## 1.2.0

- a toooon of fixeeessss
- mod doesnt break logbook now
- non drone summons like SnowtimeToybox turret now wont trigger DroneCommand menu
- fixed conflicts with WolfoFixes and a bunch of modes
- BetterCommand compatibility
- added option to only pick from drones of the same tier

## 1.1.0

- Fixed conflicts with other command artifact mods

## 1.0.0

- First release