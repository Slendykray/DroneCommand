## 1.0.1

- Updated in-game icon

## 1.0.0

- First release