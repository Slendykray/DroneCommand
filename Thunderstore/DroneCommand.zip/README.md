# DroneCommand

Adds artifact that allows you to choose drones.

Thanks theroosterboi for commissioning!

My commissions are open, contact me via discord @slendykray

[![](https://github.com/Slendykray/DroneCommand/blob/main/Images/Screenshot%20(129).png?raw=true)](https://github.com/Slendykray/DroneCommand/blob/main/Images/Screenshot%20(129).png?raw=true)

[![](https://github.com/Slendykray/DroneCommand/blob/main/Images/BoringOption.png?raw=true)](https://github.com/Slendykray/DroneCommand/blob/main/Images/BoringOption.png?raw=true)

[![](https://github.com/Slendykray/DroneCommand/blob/main/Images/Screenshot%20(121).png?raw=true)](https://github.com/Slendykray/DroneCommand/blob/main/Images/Screenshot%20(121).png?raw=true)