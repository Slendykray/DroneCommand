# DroneCommand

Adds artifact that allows you to choose drones.

Thanks theroosterboi for commissioning!

My commissions are open, contact me via discord @slendykray

[![](https://github.com/Slendykray/DroneCommand/blob/main/Images/Screenshot%20(121).png?raw=true)](https://github.com/Slendykray/DroneCommand/blob/main/Images/Screenshot%20(121).png?raw=true)

# Known Issues
- If you are using CommandItemCount disable EnableTooltip option, or it will break drone selection screen
- Other command artifact mods don't affect drone selection screen